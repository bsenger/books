import streamlit as st

def top_products_main():
    st.title('Work in progress')
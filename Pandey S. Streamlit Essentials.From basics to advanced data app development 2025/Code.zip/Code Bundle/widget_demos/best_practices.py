import streamlit as st

st.title('Consistent Aesthetic Example')



st.write('Select a date:')
st.date_input('Date')

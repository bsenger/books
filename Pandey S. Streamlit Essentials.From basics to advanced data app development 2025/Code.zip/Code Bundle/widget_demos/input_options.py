import streamlit as st

color = st.color_picker('Pick A Color', '#00f900')




#picture = st.camera_input("Take a picture")




#uploaded_file = st.file_uploader("Choose a file")




# st.date_input('Select a date')

# st.time_input('Select a time')
#
# today = datetime.date.today()
# last_week =  today - datetime.timedelta(days=7)
# st.date_input(
#             "Select date range ",
#             value =  (last_week ,today),
#             min_value = datetime.date(2022, 12, 1),
#             max_value = datetime.date.today(),
#             format="MM.DD.YYYY",
#             )


#st.number_input('Enter a number', min_value=0, max_value=100, step=1)


#st.text_input('Enter your name:', 'Type here...')
#st.text_area('Enter your message:', 'Type here...')

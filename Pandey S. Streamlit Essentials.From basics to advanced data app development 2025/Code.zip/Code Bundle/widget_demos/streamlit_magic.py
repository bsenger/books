
import pandas as pd
"## This is a header"
"And this is simple text"

df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
df
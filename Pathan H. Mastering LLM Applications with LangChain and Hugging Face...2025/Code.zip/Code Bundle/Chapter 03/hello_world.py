print("Hello World!!!")
print(
    "This is the book - Building LLM applications with Langchain and Hugging Face Transformers"
)

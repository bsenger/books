#The project is by Mohannad, Hamza and Laith for Dr. Alaa, we hope you like it
print("Welcome to the math exam")
print("The exam will be 3 levels")
print("Let's start at Level 1")

score1 = 0

Q1 = "2x4"
A1 = 8

Q2 = "3x5"
A2 = 15

Q3 = "2X6"
A3 = 12

Q4 = "2X8"
A4 = 16

Q5 = "4X5"
A5 = 20

print(Q1, " = ")
answer = int(input(""))

if answer == A1:
    score1 +=1
    
print(Q2, " = ")
answer = int(input(""))

if answer == A2:
    score1 +=1
    
print(Q3, " = ")
answer = int(input(""))

if answer == A3:
    score1 +=1
    
print(Q4, " = ")
answer = int(input(""))

if answer == A4:
    score1 +=1
    
print(Q5, " = ")
answer = int(input(""))

if answer == A5:
    score1 +=1

print("\nTest 1 Results:")
print("You answered " + str(score1) + " out of five questions correctly.")

print("Let's start at Level 2")
print("Level 2 will be more difficult than Level 1. Be fully prepared")

score2 = 0

Q6 = "5X9"
A6 = 45

Q7 = "8X7"
A7 = 56

Q8 = "6X11"
A8 = 66

Q9 = "7X9"
A9 = 63

Q10 = "7X12"
A10 = 84

Q11 = "8X6"
A11 = 48

Q12 = "7X10"
A12 = 70

Q13 = "9X9"
A13 = 81

Q14 = "8X9"
A14 = 72

Q15 = "9X12"
A15 = 108

print(Q6, " = ")
answer = int(input(""))

if answer == A6:
    score2 +=1
    
print(Q7, " = ")
answer = int(input(""))

if answer == A7:
    score2 +=1
    
print(Q8, " = ")
answer = int(input(""))

if answer == A8:
    score2 +=1
    
print(Q9, " = ")
answer = int(input(""))

if answer == A9:
    score2 +=1
    
print(Q10, " = ")
answer = int(input(""))

if answer == A10:
    score2 +=1
    
print(Q11, " = ")
answer = int(input(""))

if answer == A11:
    score2 +=1
    
print(Q12, " = ")
answer = int(input(""))

if answer == A12:
    score2 +=1
    
print(Q13, " = ")
answer = int(input(""))

if answer == A13:
    score2 +=1
    
print(Q14, " = ")
answer = int(input(""))

if answer == A14:
    score2 +=1
    
print(Q15, " = ")
answer = int(input(""))

if answer == A15:
    score2 +=1
    
    
print("\nTest 2 Results:")
print("You answered " + str(score2) + " out of ten questions correctly.")

print("Let's start at Level 3")
print("Well done for reaching level 3. Get ready because this is the last level and the hardest level. Good luck.")

score3 = 0

Q16 = "7X6+12"
A16 = 54

Q17 = "5X8-6"
A17 = 34

Q18 = "7X9+17"
A18 = 80

Q19 = "7X7+15"
A19 = 64

Q20 = "5X9+23"
A20 = 68

Q21 = "6X9+14"
A21 = 68

Q22 = "8X8-13"
A22 = 51

Q23 = "12X5-19"
A23 = 41

Q24 = "11X8-22"
A24 = 66

Q25 = "10X10-30"
A25 = 70

Q26 = "4X8-3"
A26 = 29

Q27 = "9X8+25"
A27 = 97

Q28 = "7X8+16"
A28 = 72

Q29 = "6X6+27"
A29 = 63

Q30 = "8X6-12"
A30 = 36

print(Q16, " = ")
answer = int(input(""))

if answer == A16:
    score3 +=1
    
print(Q17, " = ")
answer = int(input(""))

if answer == A17:
    score3 +=1
    
print(Q18, " = ")
answer = int(input(""))

if answer == A18:
    score3 +=1
    
print(Q19, " = ")
answer = int(input(""))

if answer == A19:
    score3 +=1
    
print(Q20, " = ")
answer = int(input(""))

if answer == A20:
    score3 +=1
    
print(Q21, " = ")
answer = int(input(""))

if answer == A21:
    score3 +=1
    
print(Q22, " = ")
answer = int(input(""))

if answer == A22:
    score3 +=1
    
print(Q23, " = ")
answer = int(input(""))

if answer == A23:
    score3 +=1
    
print(Q24, " = ")
answer = int(input(""))

if answer == A24:
    score3 +=1
    
print(Q25, " = ")
answer = int(input(""))

if answer == A25:
    score3 +=1
    
print(Q26, " = ")
answer = int(input(""))

if answer == A26:
    score3 +=1
    
print(Q27, " = ")
answer = int(input(""))

if answer == A27:
    score3 +=1
    
print(Q28, " = ")
answer = int(input(""))

if answer == A28:
    score3 +=1
    
print(Q29, " = ")
answer = int(input(""))

if answer == A29:
    score3 +=1
    
print(Q30, " = ")
answer = int(input(""))

if answer == A30:
    score3 +=1
    
print("\nTest 3 Results:")
print("You answered " + str(score3) + " out of Fifteen questions correctly.")

print("If you arrive here and answer all the questions correctly, I congratulate you, you are an expert in mathematics")
print("goodbye")
#The project is sponsored by Dr. Alaa. I hope you like it